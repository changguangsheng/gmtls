./CliSer portc  ipaddr ports

portc：服务器监听端口
ipaddr： 服务器转发ip
ports： 服务器转发端口

server.cert.pem  服务端加密证书
server.key.pem  服务端加密证书密钥
server_enc.cert.pem  服务端签名证书
server_enc.key.pem 服务端签名证书密钥