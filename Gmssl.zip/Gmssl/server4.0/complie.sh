gcc -o Server1  -lm Server1.c ./lib/libssl.a ./lib/libcrypto.a -I./lib/include -lpthread -ldl
