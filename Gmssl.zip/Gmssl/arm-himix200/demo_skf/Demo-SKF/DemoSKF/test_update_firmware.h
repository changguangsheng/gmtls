#ifndef __UPDATE_FIRMWARE_H__
#define __UPDATE_FIRMWARE_H__
#ifndef LINUX
#include <Windows.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

int test_update_firmware();

#ifdef __cplusplus
};
#endif

#endif	// __UPDATE_FIRMWARE_H__

