﻿** DemoSKF代码结构:
Demo-SKF 
    |
    |-  DemoSKF                               //测试代码源码
    |-  skf-lib
    |    |-arm-hisiv300                      //hisiv300对应的SKF库及头文件
    |    |-linux_x64                         //桌面linux x64平台的SKF库及头文件
    ...    ...
    ...         ...
    |
    |-  BuildDemoSKF                        //编译时输出的中间目录,make clean时会清除
    |       |- ...
    |
    |-  Release                             //编译结果输出主目录, make clean后不会清除.
            |-  arm-hisiv300                //对应平台的输出文件夹
            ...


** 编译说明
首先将SKF库复制到skf-lib下的对应目录,如果没有,则需要单独创建再复制.
* 无OPENSSL版本的demoskf编译
    在Demo-SKf目录下,执行
        make clean
        make CPU_PLAT=arm-hisiv300 

* 上述操作中,CPU_PLAT定义目标平台,其命名在config.make中有定义.上例中arm-hisiv300可换成需要的目标平台.
    对于config.make中尚未定义的平台,可仿照已有平台进行添加.

