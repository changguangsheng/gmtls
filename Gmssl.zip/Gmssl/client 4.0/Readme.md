./SerClitest ports  ipaddr  ports

portc： 监听端口
ipaddr：服务器端的ip
ports： 服务器端的端口